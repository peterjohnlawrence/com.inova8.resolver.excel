using System;
using System.Collections.Generic;
using System.Text;

namespace Resolver
{

    public class PJLInnerClass
    {
        public PJLInnerClass()
        {
        }

        public int GetAnswer()
        {
            return 44;
        }
    }
}
